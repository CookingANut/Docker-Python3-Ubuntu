"""
AutoChain Main

@author: Daemon Huang <daemonh@nvidia.com>
"""

from autochain.__pcstr import *
from autochain.__pclst import *
from collections import ChainMap
mlg = Lg(branch='MAIN')


User_Guide = """
AutoChain User Guide
----------------------------

Basic format:
    from autochain import ac 
        result = ac(target, chain, enablelog=False)

enablelog : enable log system for debug used or not
target    : The string or list you want to deal with
chain     : The string that contain series actions you want to do
            the chain's first two characters is called chain-guide(MUST HAVE IT), 
            and every functions need to be connected with chain guide such as "--RR()--RR()--R()"

----------------------------
How to write a chain?
    
    chain common format: function(keyword)[parameter]
    currently support 13 functions for chain

use below two data types as example:
    exstring = 'this is 1 string example!'
    exbatch = [
    'this is example batch line 1..',
    'this is example batch line 2?',
    'this is example batch line 3!'
    ]

1.
    RL = ac(exstring, '--RL(1)')
------ RL means remove left
it would remove the '1' left part including itself, result would be 'string example!'
choice: there support parameter[1]: --RL(1)[1] to include target itself

2.
    RR = ac(exstring, '--RR(1)')
------ RR means remove right
it would remove the '1' right part including itself, result would be 'this is'
choice: there support parameter[1]: --RR(1)[1] to include target itself

3.
    S = ac(exstring, '--S(1)')
------ S means split, it would split the '1' for this string,
default would set as S[1](0), so result would be 'this is', if using S(1)[1] result would be 'string example!'

4.
    R = ac(exstring, '--R(a)[xxx]')
------ R means replace, MUST have parameter
this would replace 'a' to 'xxx', result would be 'this is 1 string exxxxmple!', so if use R(a)[], it would erase 'a'

5.
    RES = ac(exstring, '--RES(str.*)')
------ RES means re,search
use regex search method to search first match string, result would be 'string example!'

6.
    REM = ac(exstring, '--REM(th.*)')
------ REM means re.match
use regex match method to match first head match string, result would be 'this is 1 string example!'

7.
    REFA = ac(exstring, '--REFA(.*is)')
------ REFA means re.findall
use regex match method to match all match string, result would be 'this is'

8.
    FT = ac(exstring, '--RES( 1 )--R( )[]--FT(int)')
------ FT means force type
force change type to keyword's type, FT(int/float/bytes/str/complex)

9.
    SL = ac(exbatch, '--SL(line 2)')
------ SL means search line
support regex, it would search the first match line, result would be 'this is example batch line 2?'

10.
    SLA = ac(exbatch, '--SLA(line)')
------ SLA means search line all,
support regex, it would search all match result
result would be [
'this is example batch line 1..',
'this is example batch line 2?',
'this is example batch line 3!'
]

11.
    AL = ac(exbatch, '--AL(\?)[0,-1]')
------ AL means after line and MUST have parameter [num1, num2]
num1 = 0(not including this line)/1(including this line)
num2 = after how many lines you want to catch, -1 is catch all
So this result would be ['this is example batch line 3!']

12.
    BL = ac(exbatch, '--BL(\?)[0,-1]')
------ BL means before line,
same as AL function, result would be ['this is example batch line 1..']

13.
    FOR
------ interator the target for next all function

----------------------------

practice:
    there is a test.txt and below are its content:

        FB_VENDOR           = Samsung
        ECC                 = Disabled
        ROW_REMAP           = Enabled
        ERRORCODE           = 000000000000
        TIME_END_RECIPE     = 2022-05-27T18:38:48.724898+00:00
        #EndGlobalVariableAfterTest
        #BeginSummary
        TestTime            = 30.4
        Elapsed             = 26.85
        TestStatus          = PASS
        Failure             = na
        ProcessName         = ALT
        ProcessCode         = 021
        GroupName           = na
        GroupCode           = 000
        TestErrorCode       = 000
        TestErrorMessage    = Success
        CoreFailure         = na

    example achon codes below:
    with open(logpath, 'r') as log:
        cycle_time = ac(log, '--SL(TestTime)--RL(= )--R(\\n)[]')
        print(cycle_time)

    running result: 30.4
"""

class AutoChain(object):

    function_dict = ChainMap(str_function_dict, batch_function_dict, {"FOR": None})

    def __init__(self, chain,enablelog=False):
        self.enablelog = enablelog
        if not enablelog:
            mlg.showlog  = False
            batl.showlog = False
            strl.showlog = False

        if len(chain) >= 2:
            self.steps = []
            self.steps_chain = []
            chain = chain.strip("'").strip('"')
            self.chain_guide = chain[0:2]
            self.chain = chain[2:]
            self.chain_interpreter()
            self.chain_check = True
            self.target_check = True
        else:
            self.chain_check = False
            raise mlg.error(f"'{chain}' length < 2, wrong chain format!")
    

    def show_target(self, target, msg="processing: "):
        string_target = isinstance(target, (str, bytes))
        list_target = isinstance(target, (list, tuple))

        if string_target:
            if len(target) >= 50:
                mlg.info(f"{msg}{target[:50]}......")
            else:
                mlg.info(f"{msg}{target}")
        
        if list_target:
            mlg.info(f"{msg}")
            if len(target) >= 15:
                for line in target[:15]:
                    line = line.strip('\n')
                    mlg.info(f"{line}")
                mlg.info(".......")
                mlg.info("------- Too Long, Omint others --------")
            else:
                for line in target:
                    line = line.strip('\n')
                    mlg.info(f"{line}")


    def run(self, target):
        self.show_target(target)                
        mlg.info("running chain functions one by one")       
        if self.chain_check:
            target_cycle = False
            for steps in self.steps_chain:
                if target:
                    if steps['function'] == "FOR":
                        target_cycle = True
                        mlg.warning("enable 'FOR' function, start to iterative obj...")
                        continue
                    if target_cycle:
                        target = list(map(lambda x: globals()[self.function_dict[steps['function']]](x, steps['content'], steps['parameter']), target))
                    else:
                        target = globals()[self.function_dict[steps['function']]](target, steps['content'], steps['parameter'])

                else:
                    mlg.error(f"invalid data: {target, steps}")
                    target = ""
                    mlg.debug(f"AutoChain Return: '{target}'")
                    return target

            self.show_target(target, msg="AutoChain Return: ")
            return target
        else:
            mlg.warning(f"format:{type(target)}wrong: {target}")
            return ''


    def chain_interpreter(self):
        if self.enablelog:
            print("AutoChain Logging Enabled")

        self.steps = self.chain.split(self.chain_guide)

        mlg.debug("---------* Chain interpreter *---------")
        mlg.debug(f"chain guide: {self.chain_guide}")
        mlg.debug(f"chain      : {self.chain}")
        mlg.debug(f"chain dict : ")
        
        if self.enablelog:
            print("\n{")
            for k, v in self.function_dict.items():
                space = (5-len(str(k)))*" "
                print(f'   "{k}"{space}: {v}')
            print("}\n")

        for step in self.steps:
            # future complete format:
            # function(content)[parameter]{backup}
            # [parameter] and {backup} are not must needed

            function, content, parameter, backup = "", "", 0, ""
            function = step[:step.index("(")]
            content = step[step.index("(") + 1:step.rindex(")")]
            rest_step = step[step.rindex(")"):]
            if "[" in rest_step and "]" in rest_step:
                parameter = rest_step[rest_step.index("[") + 1:rest_step.rindex("]")]
                rest_step = rest_step[rest_step.rindex("]"):]
                if "{" in rest_step and "}" in rest_step:
                    backup = rest_step[rest_step.index("{") + 1:rest_step.rindex("}")]
            
            self.steps_chain.append(
                {
                    "function" : function,
                    "content"  : content,
                    "parameter": parameter,
                    "backup"   : backup
                }
            )

        mlg.debug(f"parsing result:")
        _func_num = 1
        for each_chain in self.steps_chain:
            mlg.debug(f"---------* Func_{_func_num} *---------")
            for k, v in each_chain.items():
                mlg.debug(f"{k}" + (10-len(k))*" " + f": '{v}'")
            _func_num += 1
        mlg.debug("---------* Finish parsing *---------\n")


class ac():
    """
        call ac as a fucntion:
            >>> usage: ac(target, chain, enablelog=False)
            
            Args:
            >>> target->(string or list): 

                    this is the target you need to process
                
            >>> chain->string: 

                    contain series actions you want to do, 

                    the chain's first two characters is called chain-guide(MUST HAVE IT), 

                    and every functions need to be connected with chain guide 

                    such as "--RR()--RR()--R()[]"
                    or      ">>RR()>>RR()>>R()[]" and so on.
                
            >>> enablelog->bool, optional: 

                    enable chain parsing logs or not

            >>> Returns->(string or list):

                    the processed result

        call ac as a class:

            >>> ac.help || ac.guide || ac.h || ac.g:

                print out the usage guide
            
            >>> ac.info || ac.i || ac.v:

                print out the module info
    """
    module_name  = "autochain"
    version      = "6.2.3"
    author       = "daemonh"
    date         = "2023.03.16"
    email        = "daemonh@nvidia.com"
    import_all   = ['ac']
    py_version   = '>=3.10'

    class classproperty(property):
        # this is a backup class decorator for achon 11.x
        # to take place of (@classmethod <- @property <- usermethod)
        # use @classproperty instead
        def __get__(self, owner_self, owner_cls):
            return self.fget(owner_cls)
    
    def timecounter(func):
        import time
        def wrapper(*args, **kwargs):
            start = time.time()
            result = func(*args, **kwargs)
            end = round((time.time() - start), 3)
            if kwargs['enablelog']:
                print(f'AutoChain Running Time: {end}sec.')
            return result
        return wrapper
        
    def __new__(cls, target, chain, enablelog=False):
        # normally, ac.__call__() sequences is like below:
        # --> Meta.__call__() 
        # --> ac().__new__() 
        # --> ac().__init__()
        # --> ac.__call__()
        # now change __new__ --> __call__ directly 
        # to jump instantiation step
        return cls.__call__(target, chain, enablelog=enablelog)
    
    @staticmethod
    @timecounter
    def __call__(target, chain, enablelog):
        return AutoChain(chain, enablelog=enablelog).run(target)
    
    @classproperty
    def help(cls):
        print(User_Guide)
    
    @classmethod
    @property
    def info(cls):
        inl = Lg(branch='MODULE_INFO')
        inl.info(f"Version: {cls.version}")
        inl.info(f"Author : {cls.author}")
        inl.info(f"Contact: {cls.email}")
        inl.info(f"Date   : {cls.date}")
        
    h     = help
    g     = help
    guide = help
    i     = info
    v     = info