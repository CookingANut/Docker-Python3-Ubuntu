"""
Type:String Processing Module

@author: Daemon Huang <daemonh@nvidia.com>
"""

from autochain.__lg import Lg, when_fail_return
import re
strl = Lg(branch='STRING PROCESS')


str_function_dict = {
        "RL"  : "remove_left",
        "RR"  : "remove_right",
        "S"   : "split",
        "R"   : "replace",
        "RES" : "re_search",
        "REM" : "re_match",
        "REFA": "re_findall",
        "FT"  : "force_type"
    }


def formatlog(func, content, parameter, result=''):
    strl.debug(f"------------------------")
    strl.debug(f"function  : {func}")
    strl.debug(f"content   : {content}")
    strl.debug(f"parameter : {parameter}")
    if result:
        strl.debug(f"result    : {result}")


@when_fail_return('')
def force_type(target, content, parameter=None):
    """
        Force string to another type, only int/float/complex/bytes are supported
        Args:
            target    : The string to be converted
            content   : The type after conversion
            parameter : None

        Returns:
            The data after the type conversion
        ------------------------------------------
        将字符串强制转化成别的类型, 只支持int/float/complex/bytes
        Args:
            target    : 需要进行转换的字符串
            content   : 转换后的类型
            parameter : None

        Returns:
            经过类型转换后的数据
    """
    type_dict = {
        "str"    : str,
        "bytes"  : bytes,
        "int"    : int,
        "float"  : float,
        "complex": complex,
    }
    formatlog("force_type", content, parameter)
    try:
        if content in type_dict:
            if content == "str":
                return str(target)
            elif content == "int":
                return int(target)
            elif content == "float":
                return float(target)
            elif content == "complex":
                return complex(target)
            elif content == "bytes":
                return target.encode()
            else:
                return target
        else:
            strl.error(f"AutoChain only support {type_dict.keys()} force type")
            return target
    except Exception as e:
        strl.error(e)
        strl.error(f"force_type error: {type(target)}: {target} can not -> {content}")
        return target


@when_fail_return('')
def remove_left(target, content, parameter=None):
    """
        Remove the left side of the target substring from the target string
        Args:
            target    : Target string
            content   : target substring
            parameter : parameter

        Returns:
            The string to the right of the target substring
        ------------------------------------------
        移除目标字符串中目标子字符串的左边
        Args:
            target    : 目标字符串
            content   : 目标子字符串
            parameter : 参数, 1=contanin target

        Returns:
            目标子字符串右边的字符串
    """
    if parameter == '1':
        result = content + target.split(content, 1)[1]
    else:
        result = target.split(content, 1)[1]
    formatlog("remove_left", content, parameter, result)
    return result


@when_fail_return('')
def remove_right(target, content, parameter=None):
    """
        移除目标字符串中目标子字符串的右边
        Args:
            target    : 目标字符串
            content   : 目标子字符串
            parameter : 参数, 1=contanin target

        Returns:
            目标子字符串左边的字符串
    """
    if parameter == '1':
        result = target.split(content, 1)[0] + content
    else:
        result = target.split(content, 1)[0]
    formatlog("remove_right", content, parameter, result)
    return result


@when_fail_return('')
def split(target, content, parameter):
    """
        Remove the right side of the target substring from the target string
        Args:
            target    : Target string
            content   : target substring
            parameter : parameter

        Returns:
            The string to the left of the target substring
        ------------------------------------------            
        按照子字符串分割目标字符串
        Args:
            target    : 目标字符串
            content   : 子字符串
            parameter : 分割字符串的第parameter个

        Returns:
            按照子字符串分割后的第parameter个字符串
        
        注意：
            S()不带[]的话, parameter为0, 相当于把target之前的提出来,
            1相当于第一个target之后的(第二个target之前的),
            2相当于第二个target之后的
            S()如果参数没写对会出现 Indexstrl.error的情况

    """

    strl.debug(f"func: split, content: {content}, parameter: {parameter}")
    try:
        parameter = int(parameter)
        result = target.split(content)[parameter]
        formatlog("split", content, parameter, result)
        return result
    except ValueError:
        strl.error(f"split: parameter '{parameter}' can not identify split's index")
        return ""


@when_fail_return('')
def replace(target, content, parameter):
    """
        Replace the target string
        Args:
            target    : target string
            content   : substring
            parameter : replacement target

        Returns:
            Replace the target string

        Example: 
            scp("---5464565--45345--4353","---R(-)[2]")
            is equivalent to replacing all -'s with 2's

        Note that.
            R() must be with [], otherwise Typestrl.error will appear
        ------------------------------------------  
        替换目标字符串
        Args:
            target    : 目标字符串
            content   : 子字符串
            parameter : 替换目标

        Returns:
            替换目标字符串

        举例: 
            scp("---5464565---45345--4353","--R(-)[2]")
            相当于把所有-都替换为2

        注意：
            R()必须带[],不然会出现Typestrl.error
    """

    result = target.replace(content, parameter)
    formatlog("replace", content, parameter, result)
    return result


@when_fail_return('')
def re_search(target, content, parameter=0):
    """
        Matching strings using the regular expression search method
        Args:
            target    : Target string
            content   : Regular expression
            parameter : default is 0, only one match

        Returns:
            target string or empty string (failed)
        ------------------------------------------  
        使用正则表达式search方法匹配字符串
        Args:
            target   : 目标字符串
            content   : 正则表达式
            parameter : 默认为0, 只匹配一个

        Returns:
            目标字符串 or 空字符串（匹配失败）
    """

    formatlog("re_search", content, parameter)
    result = re.search(pattern=content, string=target, flags=parameter)
    if result:
        strl.debug(f"result    : {result}")
        return result[0]
    else:
        strl.error(f"re_search: not found any matches")
        return ""


@when_fail_return('')
def re_match(target, content, parameter=0):
    """
        Matching strings using the regular expression match method
        Args:
            target    : Target string
            content   : Regular expression
            parameter : default is 0, only one match

        Returns:
            target string or empty string (failed)
        ------------------------------------------ 
        使用正则表达式match方法匹配字符串
        Args:
            target    : 目标字符串
            content   : 正则表达式
            parameter : 默认为0, 只匹配一个

        Returns:
            目标字符串 or 空字符串（匹配失败
    """

    formatlog("re_match", content, parameter)
    result = re.match(pattern=content, string=target, flags=parameter)
    if result:
        strl.debug(f"result    : {result}")
        return result[0]
    else:
        strl.error(f"re_match: not found any matches")
        return ""


@when_fail_return('')
def re_findall(target, content, parameter=0):
    """
        Matching strings using the regular expression findall method
        Args:
            target    : Target string
            content   : Regular expression
            parameter : default is 0, only one match

        Returns:
            target string or empty string (failed)
        ------------------------------------------ 
        使用正则表达式findall方法匹配字符串
        Args:
            target    : 目标字符串
            content   : 正则表达式
            parameter : 默认为0, 符合条件的第parameter个字符串

        Returns:
            目标字符串 or 空字符串（匹配失败）
    """

    formatlog("re_findall", content, parameter)
    result = re.findall(pattern=content, string=target, flags=parameter)
    if result:
        strl.debug(f"result    : {result}")
        return result[parameter]
    else:
        strl.error(f"re_findall: not found any matches")
        return ""

