"""
Type:List Processing Module

@author: Daemon Huang <daemonh@nvidia.com>
"""

from autochain.__lg import Lg, when_fail_return
import re
batl = Lg(branch='LIST PROCESS')


batch_function_dict = {
    "SL" : "search_line",
    "SLA": "search_line_all",
    "AL" : "after_line",
    "BL" : "before_line"
}


def formatlog(func, content, parameter):
    batl.debug(f"------------------------")
    batl.debug(f"function  : {func}")
    batl.debug(f"content   : {content}")
    batl.debug(f"parameter : {parameter}")


def in_str(target, content):
    return content in target


def re_str(target, content):
    return re.search(content, target)   #content is pattern, target is string


@when_fail_return([])
def search_line(target, content, parameter=None):
    """
        Find the first element of the target list that matches the content requirement
        
        Args:
            target    : The target list
            content   : The condition to be met
            parameter : None

        Returns:
            String
        --------------------------------------------
        找到第一个符合content要求的目标列表的元素
        
        Args:
            target    : 目标列表
            content   : 满足的条件
            parameter : None

        Returns:
            字符串
    """

    formatlog(func="search_line", content=content, parameter=parameter)
    for line in target:
        if re_str(line, content):
            return line 


@when_fail_return([])
def search_line_all(target, content, parameter=None):
    """
        Find all elements of the target list that match the content requirement
        
        Args:
            target    : The target list
            content   : The condition to be met
            parameter : None

        Returns:
            List
        --------------------------------------------
        找到所有符合content要求的目标列表的元素
        
        Args:
            target    : 目标列表
            content   : 满足的条件
            parameter : None

        Returns:
            列表
    """
    formatlog(func="search_line_all", content=content, parameter=parameter)
    return [line for line in target if re_str(line, content)]


@when_fail_return([])
def after_line(target, content, parameter):
    """
        Find all elements of the target list that match all elements after the content requirement
        
        Args:
            target    : The target list
            content   : The condition to be met
            parameter : None

        Returns:
            List

        Note: The
            after_line must have a parameter
            The chain parser uses the rule "--AL(content)[0,-1]"
            parameter = "0,number" or "1,number"
            0 does not contain.
            1 contains
            "1, -1" means all
        --------------------------------------------
        找到所有符合content要求之后的所有目标列表的元素
        
        Args:
            target    : 目标列表
            content   : 满足的条件
            parameter : None

        Returns:
            列表

        注意：
            after_line一定要有参数
            chain parser 使用规则为 "--AL(content)[0,-1]"
            parameter = "0,number" or "1,number"
            0 不包含，
            1 包含
            "1, -1" 表示全部
    """

    formatlog(func="after_line", content=content, parameter=parameter)

    including_flag = parameter.split(',')[0]
    line = parameter.split(',')[1]

    for idx in range(len(target)):
        if re_str(target[idx], content):
            if including_flag == '0':
                if line != '-1':
                    return target[idx+1:idx+1+int(line)]
                else:
                    return target[idx+1:]

            if including_flag == '1':
                if line != '-1':
                    return target[idx:idx+1+int(line)]
                else:
                    return target[idx:]
            else:
                batl.error(f'after_line paramenters :{parameter}, invalid parameter')


@when_fail_return([])
def before_line(target, content, parameter):
    """
    Find all the elements of the target list that match the content requirement before
        
        Args:
            target    : The target list
            content   : The condition to be met
            parameter : None

        Returns:
            List
            
        Note that
            before_line must have a parameter
            The chain parser uses the rule "--AL(content)[0,-1]"
            parameter = "0,number" or "1,number"
            0 does not contain.
            1 contains
            "1, -1" means all
        --------------------------------------------
        找到所有符合content要求之前的所有目标列表的元素
        
        Args:
            target    : 目标列表
            content   : 满足的条件
            parameter : None

        Returns:
            列表
            
        注意：
            before_line一定要有参数
            chain parser 使用规则为 "--AL(content)[0,-1]"
            parameter = "0,number" or "1,number"
            0 不包含，
            1 包含
            "1, -1" 表示全部
    """
    formatlog(func="before_line", content=content, parameter=parameter)

    including_flag = parameter.split(',')[0]
    line = parameter.split(',')[1]

    for idx in range(len(target)):
        if re_str(target[idx], content):
            if including_flag == '0':
                if line != '-1':
                    return target[idx-int(line):idx]
                else:
                    return target[:idx]

            if including_flag == '1':
                if line != '-1':
                    return target[idx-int(line):idx+1]
                else:
                    return target[:idx+1]
            else:
                batl.error(f'before_line paramenters :{parameter}, invalid parameter')

