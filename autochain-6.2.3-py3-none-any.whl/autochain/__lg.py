"""
AutoChain Logging module

@author: Daemon Huang <daemonh@nvidia.com>
"""

import logging


def logorder(func):
    def wrapper(self, msg):
        if self.showlog:
            if self.branch:
                getattr(logging, func.__name__)(msg=f"[{self.branch}] - {msg}")
            else:
                getattr(logging, func.__name__)(msg=f" {msg}")
        else:
            pass
        return func(self, msg)
    return wrapper


def when_fail_return(value=''):
  def decorate(f):
    def applicator(*args, **kwargs):
      try:
         return f(*args,**kwargs)
      except Exception as e:
         print("------------------------------------")
         print("Warnning raised!")
         print(f'There has an error occurred when excute chain-function: "{f.__name__}"!')
         print(f'Use fake return value: "{value}" to replace result!')
         print(f'Please check your chain logic correctness')
         print(f'------* dumping messages *------')
         print(f'error message : {repr(e)}')
         print(f'args          : {args}')
         print(f'kwargs        : {kwargs}')
         print(f'return        : {value}')
         return value
    return applicator
  return decorate


class Lg():
    """
    ChainParser Logging class
    """

    level_relation = {
        'debug'  : logging.DEBUG,
        'info'   : logging.INFO,
        'warning': logging.WARNING,
        'error'  : logging.ERROR
    }

    def __init__(self,branch=None, llevel='debug', showlog=True, timestamp="Yes"):
        self.showlog = showlog
        self.branch = branch
        if timestamp == "No":
            logging.basicConfig(level=self.level_relation[llevel],format='[%(levelname)s]%(message)s')
        elif timestamp == "Yes":
            logging.basicConfig(level=self.level_relation[llevel],format='%(asctime)s [%(levelname)s]%(message)s')
        else:
            logging.basicConfig(level=self.level_relation[llevel],format='%(asctime)s [%(levelname)s]%(message)s')

    @logorder
    def info(self, msg):
        pass
    
    @logorder
    def debug(self, msg):
        pass
    
    @logorder
    def warning(self, msg):
        pass
    
    @logorder
    def error(self, msg):
        pass
