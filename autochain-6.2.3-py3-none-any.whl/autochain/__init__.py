# Welcome to use AutoChain!
# daemonh@nvidia.com

from autochain.ac import ac

"""
call ac as fucntion:
    usage: 
        ac(target, chain, enablelog=False)
    
    Args:
        target->type: string || list: 

                this is the target you need to process
            
        chain->type: string: 
                contain series actions you want to do, 
                the chain's first two characters is called chain-guide(MUST HAVE IT), 
                and every functions need to be connected with chain guide 
                such as "--RR(x)--RR(xx)--R(xx)[x]"
                or      ">>RR(x)>>RR(xx)>>R(xx)[x]", etc.
            
        enablelog->bool(optional): 
                enable chain parsing logs or not

        Returns->type: string || list:
                the processed result(depend on the result type your want)

call ac as class:
    ac.help || ac.guide || ac.h || ac.g:
        print out the usage guide
    
    ac.info || ac.i || ac.v:
        print out the module info
"""

version = ac.version
author  = ac.author
date    = ac.date
mail    = ac.email
__all__ = ac.import_all
pyr     = ac.py_version
name    = ac.module_name